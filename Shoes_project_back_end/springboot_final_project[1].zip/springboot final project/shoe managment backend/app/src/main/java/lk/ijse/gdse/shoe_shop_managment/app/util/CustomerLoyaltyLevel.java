package lk.ijse.gdse.shoe_shop_managment.app.util;

public enum CustomerLoyaltyLevel {
    GOLD,SILVER,BRONZE,NEW
}
