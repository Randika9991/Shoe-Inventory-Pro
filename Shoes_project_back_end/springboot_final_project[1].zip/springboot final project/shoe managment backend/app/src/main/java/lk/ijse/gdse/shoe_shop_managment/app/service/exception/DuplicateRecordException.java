package lk.ijse.gdse.shoe_shop_managment.app.service.exception;

public class DuplicateRecordException extends ServiceException{
    public DuplicateRecordException(String message) {
        super(message);
    }
}
