package lk.ijse.gdse.shoe_shop_managment.app.service.exception;

public class NotFoundException extends ServiceException{
    public NotFoundException(String message) {
        super(message);
    }
}
