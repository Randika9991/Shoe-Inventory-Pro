package lk.ijse.gdse.shoe_shop_managment.app.service.exception;

public class ServiceException extends RuntimeException{
    public ServiceException(String message) {
        super(message);
    }
}
