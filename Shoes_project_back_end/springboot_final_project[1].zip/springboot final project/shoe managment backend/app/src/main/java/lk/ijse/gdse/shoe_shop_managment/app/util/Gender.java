package lk.ijse.gdse.shoe_shop_managment.app.util;

public enum Gender {
    MALE,FEMALE,OTHER
}
